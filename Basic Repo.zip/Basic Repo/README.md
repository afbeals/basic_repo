To upload this to Github:

- created new repo on github without init. through readme
- create local repo with same name
- create initial content
- add and commit changes to local repo
- push to github
- make a few more changes to content
- add and commit changes on local
- push final changes to github repo
- push wiki to github repo